<?php

/* base.html.twig */
class __TwigTemplate_0f7392102991309cf27a0a919ffad8cb4a1ac73166363ccbc7b612edd07f4f0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'menu' => array($this, 'block_menu'),
            'body' => array($this, 'block_body'),
            'contato' => array($this, 'block_contato'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_328b3dc17ee7b6af92749fac52cfc1631475f51a8d4701d6bcdc92150adfca0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_328b3dc17ee7b6af92749fac52cfc1631475f51a8d4701d6bcdc92150adfca0f->enter($__internal_328b3dc17ee7b6af92749fac52cfc1631475f51a8d4701d6bcdc92150adfca0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_029f9e6048d3edfee22128a7d853884dbb21223ba308487018be340e27a7b992 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_029f9e6048d3edfee22128a7d853884dbb21223ba308487018be340e27a7b992->enter($__internal_029f9e6048d3edfee22128a7d853884dbb21223ba308487018be340e27a7b992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>O Atelie</title>

\t";
        // line 14
        $this->displayBlock('styles', $context, $blocks);
        // line 25
        echo "    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top topnav\" role=\"navigation\">
        <div class=\"container topnav\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand topnav\" href=\"#\">O Ateliê</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                <ul class=\"nav navbar-nav navbar-right\">
                    ";
        // line 52
        $this->displayBlock('menu', $context, $blocks);
        // line 66
        echo "                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Header -->

\t";
        // line 74
        $this->displayBlock('body', $context, $blocks);
        // line 76
        echo "
\t";
        // line 77
        $this->displayBlock('contato', $context, $blocks);
        // line 107
        echo "
    <!-- Footer -->
    <footer>
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <ul class=\"list-inline\">
                        <li>
                            <a href=\"";
        // line 115
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("inicio");
        echo "\">Início</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"";
        // line 119
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("servicos");
        echo "\">Serviços</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"";
        // line 123
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sucessos");
        echo "\">Alguns Sucessos</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"";
        // line 127
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\">Acessar</a>
                        </li>
                    </ul>
                    <p class=\"copyright text-muted small\">Copyright &copy; O Ateliê 2017. Todos os Direitos Reservados</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src=";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/jquery.js"), "html", null, true);
        echo "></script>

    <!-- Bootstrap Core JavaScript -->
    <script src=";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/js/bootstrap.min.js"), "html", null, true);
        echo "></script>

</body>

</html>
";
        
        $__internal_328b3dc17ee7b6af92749fac52cfc1631475f51a8d4701d6bcdc92150adfca0f->leave($__internal_328b3dc17ee7b6af92749fac52cfc1631475f51a8d4701d6bcdc92150adfca0f_prof);

        
        $__internal_029f9e6048d3edfee22128a7d853884dbb21223ba308487018be340e27a7b992->leave($__internal_029f9e6048d3edfee22128a7d853884dbb21223ba308487018be340e27a7b992_prof);

    }

    // line 14
    public function block_styles($context, array $blocks = array())
    {
        $__internal_3b91bb6af0ed3a0f38154717faf11253a5b76d0964dd141b869670409e8feb69 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b91bb6af0ed3a0f38154717faf11253a5b76d0964dd141b869670409e8feb69->enter($__internal_3b91bb6af0ed3a0f38154717faf11253a5b76d0964dd141b869670409e8feb69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        $__internal_43087df6821d7b12d271230dc69de7dbd206430061fc66c109af6a63e52aa1a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43087df6821d7b12d271230dc69de7dbd206430061fc66c109af6a63e52aa1a6->enter($__internal_43087df6821d7b12d271230dc69de7dbd206430061fc66c109af6a63e52aa1a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 15
        echo "    <!-- Bootstrap Core CSS -->
    <link href=";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/bootstrap.min.css"), "html", null, true);
        echo " rel=\"stylesheet\">

    <!-- Custom CSS -->
    <link href=";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/css/landing-page.css"), "html", null, true);
        echo " rel=\"stylesheet\">

    <!-- Custom Fonts -->
    <link href=";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo " rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic\" rel=\"stylesheet\" type=\"text/css\">
\t";
        
        $__internal_43087df6821d7b12d271230dc69de7dbd206430061fc66c109af6a63e52aa1a6->leave($__internal_43087df6821d7b12d271230dc69de7dbd206430061fc66c109af6a63e52aa1a6_prof);

        
        $__internal_3b91bb6af0ed3a0f38154717faf11253a5b76d0964dd141b869670409e8feb69->leave($__internal_3b91bb6af0ed3a0f38154717faf11253a5b76d0964dd141b869670409e8feb69_prof);

    }

    // line 52
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c1734ee56db68f9a426b8daf9b8feeb3c17be9d2a6ecc8c92861ccbc9588c4f1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1734ee56db68f9a426b8daf9b8feeb3c17be9d2a6ecc8c92861ccbc9588c4f1->enter($__internal_c1734ee56db68f9a426b8daf9b8feeb3c17be9d2a6ecc8c92861ccbc9588c4f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_e746fdd44e1cd8c97a01ff7714622b3e2d2705dcb0259b2a50a1a4553da75d83 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e746fdd44e1cd8c97a01ff7714622b3e2d2705dcb0259b2a50a1a4553da75d83->enter($__internal_e746fdd44e1cd8c97a01ff7714622b3e2d2705dcb0259b2a50a1a4553da75d83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 53
        echo "                    <li>
                        <a href=\"";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("inicio");
        echo "\">Início</a>
                    </li>
                    <li>
                        <a href=\"";
        // line 57
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("servicos");
        echo "\">Serviços</a>
                    </li>
                    <li>
                        <a href=\"";
        // line 60
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sucessos");
        echo "\">Alguns Sucessos</a>
                    </li>
                    <li>
                        <a href=\"";
        // line 63
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\">Acessar</a>
                    </li>
                    ";
        
        $__internal_e746fdd44e1cd8c97a01ff7714622b3e2d2705dcb0259b2a50a1a4553da75d83->leave($__internal_e746fdd44e1cd8c97a01ff7714622b3e2d2705dcb0259b2a50a1a4553da75d83_prof);

        
        $__internal_c1734ee56db68f9a426b8daf9b8feeb3c17be9d2a6ecc8c92861ccbc9588c4f1->leave($__internal_c1734ee56db68f9a426b8daf9b8feeb3c17be9d2a6ecc8c92861ccbc9588c4f1_prof);

    }

    // line 74
    public function block_body($context, array $blocks = array())
    {
        $__internal_fe72dce30daa1ae7d87d552c291f0e18ab1512a89a885a4f923a7dde9639ac11 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe72dce30daa1ae7d87d552c291f0e18ab1512a89a885a4f923a7dde9639ac11->enter($__internal_fe72dce30daa1ae7d87d552c291f0e18ab1512a89a885a4f923a7dde9639ac11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c743bf61c4a1a1002189aa540b4de2f9df4f6c3a87bdfd00e324b2af6d2ec7ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c743bf61c4a1a1002189aa540b4de2f9df4f6c3a87bdfd00e324b2af6d2ec7ee->enter($__internal_c743bf61c4a1a1002189aa540b4de2f9df4f6c3a87bdfd00e324b2af6d2ec7ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 75
        echo "\t";
        
        $__internal_c743bf61c4a1a1002189aa540b4de2f9df4f6c3a87bdfd00e324b2af6d2ec7ee->leave($__internal_c743bf61c4a1a1002189aa540b4de2f9df4f6c3a87bdfd00e324b2af6d2ec7ee_prof);

        
        $__internal_fe72dce30daa1ae7d87d552c291f0e18ab1512a89a885a4f923a7dde9639ac11->leave($__internal_fe72dce30daa1ae7d87d552c291f0e18ab1512a89a885a4f923a7dde9639ac11_prof);

    }

    // line 77
    public function block_contato($context, array $blocks = array())
    {
        $__internal_c6d0fbd991751a53f8fc388552f705f8af03cb9ed2a72d38d4fe34be12541d5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6d0fbd991751a53f8fc388552f705f8af03cb9ed2a72d38d4fe34be12541d5b->enter($__internal_c6d0fbd991751a53f8fc388552f705f8af03cb9ed2a72d38d4fe34be12541d5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        $__internal_39231cb4e37258fabf8f700989cb5463469d69d696bf12e3ef81af5f713d79e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39231cb4e37258fabf8f700989cb5463469d69d696bf12e3ef81af5f713d79e9->enter($__internal_39231cb4e37258fabf8f700989cb5463469d69d696bf12e3ef81af5f713d79e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        // line 78
        echo "\t<div class=\"banner\">

        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-lg-6\">
                    <h2>Siga-nos nas redes sociais:</h2>
                </div>
                <div class=\"col-lg-6\">
                    <ul class=\"list-inline banner-social-buttons\">
                        <li>
                            <a href=\"https://twitter.com/SBootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-twitter fa-fw\"></i> <span class=\"network-name\">Twitter</span></a>
                        </li>
                        <li>
                            <a href=\"https://github.com/IronSummitMedia/startbootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-facebook fa-fw\"></i> <span class=\"network-name\">Facebook</span></a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-whatsapp fa-fw\"></i> <span class=\"network-name\">WhatsApp</span></a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.banner -->
\t";
        
        $__internal_39231cb4e37258fabf8f700989cb5463469d69d696bf12e3ef81af5f713d79e9->leave($__internal_39231cb4e37258fabf8f700989cb5463469d69d696bf12e3ef81af5f713d79e9_prof);

        
        $__internal_c6d0fbd991751a53f8fc388552f705f8af03cb9ed2a72d38d4fe34be12541d5b->leave($__internal_c6d0fbd991751a53f8fc388552f705f8af03cb9ed2a72d38d4fe34be12541d5b_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  268 => 78,  259 => 77,  249 => 75,  240 => 74,  227 => 63,  221 => 60,  215 => 57,  209 => 54,  206 => 53,  197 => 52,  184 => 22,  178 => 19,  172 => 16,  169 => 15,  160 => 14,  144 => 140,  138 => 137,  125 => 127,  118 => 123,  111 => 119,  104 => 115,  94 => 107,  92 => 77,  89 => 76,  87 => 74,  77 => 66,  75 => 52,  46 => 25,  44 => 14,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">

<head>

    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">

    <title>O Atelie</title>

\t{%  block styles %}
    <!-- Bootstrap Core CSS -->
    <link href={{ asset('assets/css/bootstrap.min.css')}} rel=\"stylesheet\">

    <!-- Custom CSS -->
    <link href={{ asset('assets/css/landing-page.css')}} rel=\"stylesheet\">

    <!-- Custom Fonts -->
    <link href={{ asset('assets/font-awesome/css/font-awesome.min.css')}} rel=\"stylesheet\" type=\"text/css\">
    <link href=\"https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic\" rel=\"stylesheet\" type=\"text/css\">
\t{% endblock %}
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src=\"https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js\"></script>
        <script src=\"https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js\"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class=\"navbar navbar-default navbar-fixed-top topnav\" role=\"navigation\">
        <div class=\"container topnav\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand topnav\" href=\"#\">O Ateliê</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                <ul class=\"nav navbar-nav navbar-right\">
                    {% block menu %}
                    <li>
                        <a href=\"{{ path('inicio') }}\">Início</a>
                    </li>
                    <li>
                        <a href=\"{{ path('servicos') }}\">Serviços</a>
                    </li>
                    <li>
                        <a href=\"{{ path('sucessos') }}\">Alguns Sucessos</a>
                    </li>
                    <li>
                        <a href=\"{{ path('login') }}\">Acessar</a>
                    </li>
                    {% endblock %}
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
    <!-- Header -->

\t{% block body %}
\t{% endblock %}

\t{% block contato %}
\t<div class=\"banner\">

        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-lg-6\">
                    <h2>Siga-nos nas redes sociais:</h2>
                </div>
                <div class=\"col-lg-6\">
                    <ul class=\"list-inline banner-social-buttons\">
                        <li>
                            <a href=\"https://twitter.com/SBootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-twitter fa-fw\"></i> <span class=\"network-name\">Twitter</span></a>
                        </li>
                        <li>
                            <a href=\"https://github.com/IronSummitMedia/startbootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-facebook fa-fw\"></i> <span class=\"network-name\">Facebook</span></a>
                        </li>
                        <li>
                            <a href=\"#\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-whatsapp fa-fw\"></i> <span class=\"network-name\">WhatsApp</span></a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.banner -->
\t{% endblock %}

    <!-- Footer -->
    <footer>
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-lg-12\">
                    <ul class=\"list-inline\">
                        <li>
                            <a href=\"{{ path('inicio') }}\">Início</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"{{ path('servicos') }}\">Serviços</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"{{ path('sucessos') }}\">Alguns Sucessos</a>
                        </li>
                        <li class=\"footer-menu-divider\">&sdot;</li>
                        <li>
                            <a href=\"{{ path('login') }}\">Acessar</a>
                        </li>
                    </ul>
                    <p class=\"copyright text-muted small\">Copyright &copy; O Ateliê 2017. Todos os Direitos Reservados</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src={{ asset('assets/js/jquery.js') }}></script>

    <!-- Bootstrap Core JavaScript -->
    <script src={{ asset('assets/js/bootstrap.min.js') }}></script>

</body>

</html>
", "base.html.twig", "/home/jadercleber/Workspace/Atelie/app/Resources/views/base.html.twig");
    }
}
