<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_a611f92a27af130951d9078fddf1bbafe1cc49e2bd58b9706ba15334252c5e8a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5eebda7ee8c278d9242f2967792ea10157d5d0cd2f65b5e0d3fcd7c18038a5eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5eebda7ee8c278d9242f2967792ea10157d5d0cd2f65b5e0d3fcd7c18038a5eb->enter($__internal_5eebda7ee8c278d9242f2967792ea10157d5d0cd2f65b5e0d3fcd7c18038a5eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_72096684c927e6650a3fa3f8748aad84af0529b19bd78452ef57e0a8f52f6822 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72096684c927e6650a3fa3f8748aad84af0529b19bd78452ef57e0a8f52f6822->enter($__internal_72096684c927e6650a3fa3f8748aad84af0529b19bd78452ef57e0a8f52f6822_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5eebda7ee8c278d9242f2967792ea10157d5d0cd2f65b5e0d3fcd7c18038a5eb->leave($__internal_5eebda7ee8c278d9242f2967792ea10157d5d0cd2f65b5e0d3fcd7c18038a5eb_prof);

        
        $__internal_72096684c927e6650a3fa3f8748aad84af0529b19bd78452ef57e0a8f52f6822->leave($__internal_72096684c927e6650a3fa3f8748aad84af0529b19bd78452ef57e0a8f52f6822_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_73d214503768a67fccea036e938fca6b2acb1d491576f054e377d7e93eeb4952 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_73d214503768a67fccea036e938fca6b2acb1d491576f054e377d7e93eeb4952->enter($__internal_73d214503768a67fccea036e938fca6b2acb1d491576f054e377d7e93eeb4952_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_cb95adc3a97315305d4b97f99981623473d664c9c8ab16b8f5c2a6f9ca474999 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb95adc3a97315305d4b97f99981623473d664c9c8ab16b8f5c2a6f9ca474999->enter($__internal_cb95adc3a97315305d4b97f99981623473d664c9c8ab16b8f5c2a6f9ca474999_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_cb95adc3a97315305d4b97f99981623473d664c9c8ab16b8f5c2a6f9ca474999->leave($__internal_cb95adc3a97315305d4b97f99981623473d664c9c8ab16b8f5c2a6f9ca474999_prof);

        
        $__internal_73d214503768a67fccea036e938fca6b2acb1d491576f054e377d7e93eeb4952->leave($__internal_73d214503768a67fccea036e938fca6b2acb1d491576f054e377d7e93eeb4952_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_dd7de319eb1e0b01836304ae07857d45a923e4b802fbbd1d2c101149ba1637c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd7de319eb1e0b01836304ae07857d45a923e4b802fbbd1d2c101149ba1637c7->enter($__internal_dd7de319eb1e0b01836304ae07857d45a923e4b802fbbd1d2c101149ba1637c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d098d29f00a0cdbfe9f155f8840de59516979a056412c84a569979cdd7e73d04 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d098d29f00a0cdbfe9f155f8840de59516979a056412c84a569979cdd7e73d04->enter($__internal_d098d29f00a0cdbfe9f155f8840de59516979a056412c84a569979cdd7e73d04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_d098d29f00a0cdbfe9f155f8840de59516979a056412c84a569979cdd7e73d04->leave($__internal_d098d29f00a0cdbfe9f155f8840de59516979a056412c84a569979cdd7e73d04_prof);

        
        $__internal_dd7de319eb1e0b01836304ae07857d45a923e4b802fbbd1d2c101149ba1637c7->leave($__internal_dd7de319eb1e0b01836304ae07857d45a923e4b802fbbd1d2c101149ba1637c7_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_6dbce00f181a767b1c9efb2e5179dfe5b62e674f4953065436c633078ff4c1f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6dbce00f181a767b1c9efb2e5179dfe5b62e674f4953065436c633078ff4c1f4->enter($__internal_6dbce00f181a767b1c9efb2e5179dfe5b62e674f4953065436c633078ff4c1f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_84554d25ece9a449f81095e18113e45ebc6e6e18bb5004d40f30544b84e6d0e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84554d25ece9a449f81095e18113e45ebc6e6e18bb5004d40f30544b84e6d0e1->enter($__internal_84554d25ece9a449f81095e18113e45ebc6e6e18bb5004d40f30544b84e6d0e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_84554d25ece9a449f81095e18113e45ebc6e6e18bb5004d40f30544b84e6d0e1->leave($__internal_84554d25ece9a449f81095e18113e45ebc6e6e18bb5004d40f30544b84e6d0e1_prof);

        
        $__internal_6dbce00f181a767b1c9efb2e5179dfe5b62e674f4953065436c633078ff4c1f4->leave($__internal_6dbce00f181a767b1c9efb2e5179dfe5b62e674f4953065436c633078ff4c1f4_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/home/jadercleber/Workspace/Atelie/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
