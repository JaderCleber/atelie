<?php

/* default/app-caixa.html.twig */
class __TwigTemplate_f0cd77e2f5ddc1c6cbe19f2dd646b61c656f64e854253884e1f9cc59b28419de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/app-caixa.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'menu' => array($this, 'block_menu'),
            'body' => array($this, 'block_body'),
            'contato' => array($this, 'block_contato'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b812c8b3835ddfe4c6f3ee741c5c003e2963f64e27d5d520c9c56292608254d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b812c8b3835ddfe4c6f3ee741c5c003e2963f64e27d5d520c9c56292608254d7->enter($__internal_b812c8b3835ddfe4c6f3ee741c5c003e2963f64e27d5d520c9c56292608254d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/app-caixa.html.twig"));

        $__internal_ce55fda318a5822c634bcc0457bd8272c2550739e6b0ed33ff1222bef272ebdf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce55fda318a5822c634bcc0457bd8272c2550739e6b0ed33ff1222bef272ebdf->enter($__internal_ce55fda318a5822c634bcc0457bd8272c2550739e6b0ed33ff1222bef272ebdf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/app-caixa.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b812c8b3835ddfe4c6f3ee741c5c003e2963f64e27d5d520c9c56292608254d7->leave($__internal_b812c8b3835ddfe4c6f3ee741c5c003e2963f64e27d5d520c9c56292608254d7_prof);

        
        $__internal_ce55fda318a5822c634bcc0457bd8272c2550739e6b0ed33ff1222bef272ebdf->leave($__internal_ce55fda318a5822c634bcc0457bd8272c2550739e6b0ed33ff1222bef272ebdf_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_5e91ef187f226e1bc20504ce860608c68659057140d4e0ad6b309ef03d905e1b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5e91ef187f226e1bc20504ce860608c68659057140d4e0ad6b309ef03d905e1b->enter($__internal_5e91ef187f226e1bc20504ce860608c68659057140d4e0ad6b309ef03d905e1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        $__internal_32c4f57d67ed43b2a1b8e48eca0f9b4235fe93987a6692aa9384fbe57014b074 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32c4f57d67ed43b2a1b8e48eca0f9b4235fe93987a6692aa9384fbe57014b074->enter($__internal_32c4f57d67ed43b2a1b8e48eca0f9b4235fe93987a6692aa9384fbe57014b074_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        $this->displayParentBlock("styles", $context, $blocks);
        echo "
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
";
        
        $__internal_32c4f57d67ed43b2a1b8e48eca0f9b4235fe93987a6692aa9384fbe57014b074->leave($__internal_32c4f57d67ed43b2a1b8e48eca0f9b4235fe93987a6692aa9384fbe57014b074_prof);

        
        $__internal_5e91ef187f226e1bc20504ce860608c68659057140d4e0ad6b309ef03d905e1b->leave($__internal_5e91ef187f226e1bc20504ce860608c68659057140d4e0ad6b309ef03d905e1b_prof);

    }

    // line 8
    public function block_menu($context, array $blocks = array())
    {
        $__internal_44844472cac4714c3e8be4994b559ad2b60ebd2b1b1784edc1938958844b95ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_44844472cac4714c3e8be4994b559ad2b60ebd2b1b1784edc1938958844b95ff->enter($__internal_44844472cac4714c3e8be4994b559ad2b60ebd2b1b1784edc1938958844b95ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_128ddf2c649d6a128acd15c211432e6b5cc9761969ca1b987daa02e3e56077e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_128ddf2c649d6a128acd15c211432e6b5cc9761969ca1b987daa02e3e56077e8->enter($__internal_128ddf2c649d6a128acd15c211432e6b5cc9761969ca1b987daa02e3e56077e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 9
        echo "  <li>
      <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("servicos");
        echo "\">Início</a>
  </li>
  <li>
      <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("servicos");
        echo "\">Etc</a>
  </li>
  <li>
      <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sucessos");
        echo "\">Conta</a>
  </li>
  <li>
      <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\">Sair</a>
  </li>
";
        
        $__internal_128ddf2c649d6a128acd15c211432e6b5cc9761969ca1b987daa02e3e56077e8->leave($__internal_128ddf2c649d6a128acd15c211432e6b5cc9761969ca1b987daa02e3e56077e8_prof);

        
        $__internal_44844472cac4714c3e8be4994b559ad2b60ebd2b1b1784edc1938958844b95ff->leave($__internal_44844472cac4714c3e8be4994b559ad2b60ebd2b1b1784edc1938958844b95ff_prof);

    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        $__internal_43068508894293724578524c653679dcbaef10024b64e036264808c1038e1cba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_43068508894293724578524c653679dcbaef10024b64e036264808c1038e1cba->enter($__internal_43068508894293724578524c653679dcbaef10024b64e036264808c1038e1cba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9fb763ec0309895ddbb3a9e7253d05594820fd83cd6561eeb7b53f94499b4522 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fb763ec0309895ddbb3a9e7253d05594820fd83cd6561eeb7b53f94499b4522->enter($__internal_9fb763ec0309895ddbb3a9e7253d05594820fd83cd6561eeb7b53f94499b4522_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 24
        echo "<div class=\"content-section-b\">

    <div class=\"container\">

      <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1 class=\"page-header\"><font style=\"background-color:#000; color:#fff;\">Controle de Caixa</font>
            </h1>
        </div>

        <!-- Botao para o controle de clientes -->
        <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h3><img src=\"img/i.png\"></i> Status dos Caixas</h3>
                    </div>
                    <div class=\"panel-body\">
                            <p>Saiba Mais</p>
                        </div>
                </div>
            </div>
        </a>
      </div>
    </div>

    <div class=\"container\">

      <div class=\"row\">

        <!-- Botao para o controle de produtos -->
        <a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_produtos");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Produtos</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de funcionarios -->
        <a href=\"";
        // line 66
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_funcionarios");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Funcionários</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de empresas -->
        <a href=\"";
        // line 77
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_empresas");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Empresas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de caixa -->
        <a href=\"";
        // line 88
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_caixa");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Caixa</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para controle de Pedidos/Encomendas -->
        <a href=\"";
        // line 99
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_pedidos");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Pedidos/Encomendas</h4>
                    </div>
                </div>
            </div>
        </a>


        <a href=\"";
        // line 110
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>

        <a href=\"";
        // line 120
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>
      </div>
    </div>
    <!-- /.container -->
</div>
    <!-- /.content-section-b -->
";
        
        $__internal_9fb763ec0309895ddbb3a9e7253d05594820fd83cd6561eeb7b53f94499b4522->leave($__internal_9fb763ec0309895ddbb3a9e7253d05594820fd83cd6561eeb7b53f94499b4522_prof);

        
        $__internal_43068508894293724578524c653679dcbaef10024b64e036264808c1038e1cba->leave($__internal_43068508894293724578524c653679dcbaef10024b64e036264808c1038e1cba_prof);

    }

    // line 136
    public function block_contato($context, array $blocks = array())
    {
        $__internal_35892a2c1eefe9b45eb41edea4eb0579dc6a7bb525af2106a44f83db2e9fa3b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35892a2c1eefe9b45eb41edea4eb0579dc6a7bb525af2106a44f83db2e9fa3b1->enter($__internal_35892a2c1eefe9b45eb41edea4eb0579dc6a7bb525af2106a44f83db2e9fa3b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        $__internal_4cfddabcf80e2152b0b31af2178be8ef8391a169db1ca2bc2cce349db2148c88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cfddabcf80e2152b0b31af2178be8ef8391a169db1ca2bc2cce349db2148c88->enter($__internal_4cfddabcf80e2152b0b31af2178be8ef8391a169db1ca2bc2cce349db2148c88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        
        $__internal_4cfddabcf80e2152b0b31af2178be8ef8391a169db1ca2bc2cce349db2148c88->leave($__internal_4cfddabcf80e2152b0b31af2178be8ef8391a169db1ca2bc2cce349db2148c88_prof);

        
        $__internal_35892a2c1eefe9b45eb41edea4eb0579dc6a7bb525af2106a44f83db2e9fa3b1->leave($__internal_35892a2c1eefe9b45eb41edea4eb0579dc6a7bb525af2106a44f83db2e9fa3b1_prof);

    }

    public function getTemplateName()
    {
        return "default/app-caixa.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  261 => 136,  236 => 120,  223 => 110,  209 => 99,  195 => 88,  181 => 77,  167 => 66,  153 => 55,  130 => 35,  117 => 24,  108 => 23,  95 => 19,  89 => 16,  83 => 13,  77 => 10,  74 => 9,  65 => 8,  52 => 4,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{%  block styles %}
{{ parent() }}
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
{% endblock %}

{% block menu %}
  <li>
      <a href=\"{{ path('servicos') }}\">Início</a>
  </li>
  <li>
      <a href=\"{{ path('servicos') }}\">Etc</a>
  </li>
  <li>
      <a href=\"{{ path('sucessos') }}\">Conta</a>
  </li>
  <li>
      <a href=\"{{ path('login') }}\">Sair</a>
  </li>
{% endblock %}

{% block body %}
<div class=\"content-section-b\">

    <div class=\"container\">

      <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1 class=\"page-header\"><font style=\"background-color:#000; color:#fff;\">Controle de Caixa</font>
            </h1>
        </div>

        <!-- Botao para o controle de clientes -->
        <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h3><img src=\"img/i.png\"></i> Status dos Caixas</h3>
                    </div>
                    <div class=\"panel-body\">
                            <p>Saiba Mais</p>
                        </div>
                </div>
            </div>
        </a>
      </div>
    </div>

    <div class=\"container\">

      <div class=\"row\">

        <!-- Botao para o controle de produtos -->
        <a href=\"{{ path('app_produtos')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Produtos</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de funcionarios -->
        <a href=\"{{ path('app_funcionarios')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Funcionários</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de empresas -->
        <a href=\"{{ path('app_empresas')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Empresas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de caixa -->
        <a href=\"{{ path('app_caixa')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Caixa</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para controle de Pedidos/Encomendas -->
        <a href=\"{{ path('app_pedidos')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Pedidos/Encomendas</h4>
                    </div>
                </div>
            </div>
        </a>


        <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>

        <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>
      </div>
    </div>
    <!-- /.container -->
</div>
    <!-- /.content-section-b -->
{% endblock %}

{% block contato %}
{% endblock %}
", "default/app-caixa.html.twig", "/home/jadercleber/Workspace/Atelie/app/Resources/views/default/app-caixa.html.twig");
    }
}
