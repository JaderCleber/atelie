<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_312d32e97ddafe02e42d73dd84757df48cb63ac2f64004156f3f507b209e3968 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e35c5f678cc4761103a962aa101bfa0f2a05822cc94675bbd492b5854995503d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e35c5f678cc4761103a962aa101bfa0f2a05822cc94675bbd492b5854995503d->enter($__internal_e35c5f678cc4761103a962aa101bfa0f2a05822cc94675bbd492b5854995503d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_698d4834ba4129db27aa1cd459efa84ad2810f2bb461543ec5a8bbb26708f217 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_698d4834ba4129db27aa1cd459efa84ad2810f2bb461543ec5a8bbb26708f217->enter($__internal_698d4834ba4129db27aa1cd459efa84ad2810f2bb461543ec5a8bbb26708f217_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_e35c5f678cc4761103a962aa101bfa0f2a05822cc94675bbd492b5854995503d->leave($__internal_e35c5f678cc4761103a962aa101bfa0f2a05822cc94675bbd492b5854995503d_prof);

        
        $__internal_698d4834ba4129db27aa1cd459efa84ad2810f2bb461543ec5a8bbb26708f217->leave($__internal_698d4834ba4129db27aa1cd459efa84ad2810f2bb461543ec5a8bbb26708f217_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "/home/jadercleber/Workspace/Atelie/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/images/chevron-right.svg");
    }
}
