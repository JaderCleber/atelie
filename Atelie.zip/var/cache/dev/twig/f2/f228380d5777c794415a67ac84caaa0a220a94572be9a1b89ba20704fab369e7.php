<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_4474101226d255a74a7722c10385d40bcfba8957126e175f8449abe3558173aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_981c6fa32d8fbecfb8a43fed73b1b7f9d67c15b6960a0114f24ac01c058795b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_981c6fa32d8fbecfb8a43fed73b1b7f9d67c15b6960a0114f24ac01c058795b3->enter($__internal_981c6fa32d8fbecfb8a43fed73b1b7f9d67c15b6960a0114f24ac01c058795b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_b6d8be78f3864c39561cfe0a7b5a44559ee04c52eb87aae9c7e34517619afe60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6d8be78f3864c39561cfe0a7b5a44559ee04c52eb87aae9c7e34517619afe60->enter($__internal_b6d8be78f3864c39561cfe0a7b5a44559ee04c52eb87aae9c7e34517619afe60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_981c6fa32d8fbecfb8a43fed73b1b7f9d67c15b6960a0114f24ac01c058795b3->leave($__internal_981c6fa32d8fbecfb8a43fed73b1b7f9d67c15b6960a0114f24ac01c058795b3_prof);

        
        $__internal_b6d8be78f3864c39561cfe0a7b5a44559ee04c52eb87aae9c7e34517619afe60->leave($__internal_b6d8be78f3864c39561cfe0a7b5a44559ee04c52eb87aae9c7e34517619afe60_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_7481a8100912f0760971c2abefbdd14264bc194b0e0f341beab3f2ea7c1a82c8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7481a8100912f0760971c2abefbdd14264bc194b0e0f341beab3f2ea7c1a82c8->enter($__internal_7481a8100912f0760971c2abefbdd14264bc194b0e0f341beab3f2ea7c1a82c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_e0084487470fb06d3898e7fa38b9ac14988e6186c04ed4546a312ea6a2b679e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0084487470fb06d3898e7fa38b9ac14988e6186c04ed4546a312ea6a2b679e3->enter($__internal_e0084487470fb06d3898e7fa38b9ac14988e6186c04ed4546a312ea6a2b679e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_e0084487470fb06d3898e7fa38b9ac14988e6186c04ed4546a312ea6a2b679e3->leave($__internal_e0084487470fb06d3898e7fa38b9ac14988e6186c04ed4546a312ea6a2b679e3_prof);

        
        $__internal_7481a8100912f0760971c2abefbdd14264bc194b0e0f341beab3f2ea7c1a82c8->leave($__internal_7481a8100912f0760971c2abefbdd14264bc194b0e0f341beab3f2ea7c1a82c8_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_456ad1a53b72a79428f11eb49d68d14b254588b8407bcc9398020d7e15d5fa61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_456ad1a53b72a79428f11eb49d68d14b254588b8407bcc9398020d7e15d5fa61->enter($__internal_456ad1a53b72a79428f11eb49d68d14b254588b8407bcc9398020d7e15d5fa61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_0269b23cac2e6c29a0b9d6483072582b773629a04a19249b21b3ba39f94cc056 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0269b23cac2e6c29a0b9d6483072582b773629a04a19249b21b3ba39f94cc056->enter($__internal_0269b23cac2e6c29a0b9d6483072582b773629a04a19249b21b3ba39f94cc056_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0269b23cac2e6c29a0b9d6483072582b773629a04a19249b21b3ba39f94cc056->leave($__internal_0269b23cac2e6c29a0b9d6483072582b773629a04a19249b21b3ba39f94cc056_prof);

        
        $__internal_456ad1a53b72a79428f11eb49d68d14b254588b8407bcc9398020d7e15d5fa61->leave($__internal_456ad1a53b72a79428f11eb49d68d14b254588b8407bcc9398020d7e15d5fa61_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_8ae3c0ef21366d93f0826d2ebb3ce9cdf296c0dea9bb5c9c7d831ecc6766796c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ae3c0ef21366d93f0826d2ebb3ce9cdf296c0dea9bb5c9c7d831ecc6766796c->enter($__internal_8ae3c0ef21366d93f0826d2ebb3ce9cdf296c0dea9bb5c9c7d831ecc6766796c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5c3e92f8e7d783b3928d100bf0dee6de3b379ee7ecd15894d3ba26be4b0055ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5c3e92f8e7d783b3928d100bf0dee6de3b379ee7ecd15894d3ba26be4b0055ee->enter($__internal_5c3e92f8e7d783b3928d100bf0dee6de3b379ee7ecd15894d3ba26be4b0055ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_5c3e92f8e7d783b3928d100bf0dee6de3b379ee7ecd15894d3ba26be4b0055ee->leave($__internal_5c3e92f8e7d783b3928d100bf0dee6de3b379ee7ecd15894d3ba26be4b0055ee_prof);

        
        $__internal_8ae3c0ef21366d93f0826d2ebb3ce9cdf296c0dea9bb5c9c7d831ecc6766796c->leave($__internal_8ae3c0ef21366d93f0826d2ebb3ce9cdf296c0dea9bb5c9c7d831ecc6766796c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/home/jadercleber/Workspace/Atelie/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
