<?php

/* default/index.html.twig */
class __TwigTemplate_eb06cea6897fcd0190b5b480f9660ee60e7cc875ac6347494ee121194322dc60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_057e599665e1cf22fc243ce6128a7c99ed4402fff6f5ede53693b4cc31767515 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_057e599665e1cf22fc243ce6128a7c99ed4402fff6f5ede53693b4cc31767515->enter($__internal_057e599665e1cf22fc243ce6128a7c99ed4402fff6f5ede53693b4cc31767515_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_833f52adeac0b67d41e67edd24c0659fcc90b95fd8eb97aa83fdc9d7e5f81e70 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_833f52adeac0b67d41e67edd24c0659fcc90b95fd8eb97aa83fdc9d7e5f81e70->enter($__internal_833f52adeac0b67d41e67edd24c0659fcc90b95fd8eb97aa83fdc9d7e5f81e70_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_057e599665e1cf22fc243ce6128a7c99ed4402fff6f5ede53693b4cc31767515->leave($__internal_057e599665e1cf22fc243ce6128a7c99ed4402fff6f5ede53693b4cc31767515_prof);

        
        $__internal_833f52adeac0b67d41e67edd24c0659fcc90b95fd8eb97aa83fdc9d7e5f81e70->leave($__internal_833f52adeac0b67d41e67edd24c0659fcc90b95fd8eb97aa83fdc9d7e5f81e70_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_1439f515a1e99a495255af22875baf08c5ff5a49ad38230f4e5f425be2f2fdb6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1439f515a1e99a495255af22875baf08c5ff5a49ad38230f4e5f425be2f2fdb6->enter($__internal_1439f515a1e99a495255af22875baf08c5ff5a49ad38230f4e5f425be2f2fdb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        $__internal_d46a23673e54caf16f45816594b06f868528c6eb5bfa546326f843a9ce004cae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d46a23673e54caf16f45816594b06f868528c6eb5bfa546326f843a9ce004cae->enter($__internal_d46a23673e54caf16f45816594b06f868528c6eb5bfa546326f843a9ce004cae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        $this->displayParentBlock("styles", $context, $blocks);
        echo "
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
";
        
        $__internal_d46a23673e54caf16f45816594b06f868528c6eb5bfa546326f843a9ce004cae->leave($__internal_d46a23673e54caf16f45816594b06f868528c6eb5bfa546326f843a9ce004cae_prof);

        
        $__internal_1439f515a1e99a495255af22875baf08c5ff5a49ad38230f4e5f425be2f2fdb6->leave($__internal_1439f515a1e99a495255af22875baf08c5ff5a49ad38230f4e5f425be2f2fdb6_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_55edaa06ffb3ce8c1247b314713154fae41b2c1e1933badfb237bff7d3c081c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_55edaa06ffb3ce8c1247b314713154fae41b2c1e1933badfb237bff7d3c081c5->enter($__internal_55edaa06ffb3ce8c1247b314713154fae41b2c1e1933badfb237bff7d3c081c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_46fd0faf5459334cc0f16bc90bf77d0911f6e1085ffed616bd16baeceb512c6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46fd0faf5459334cc0f16bc90bf77d0911f6e1085ffed616bd16baeceb512c6e->enter($__internal_46fd0faf5459334cc0f16bc90bf77d0911f6e1085ffed616bd16baeceb512c6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "<div class=\"content-section-b\">

        <div class=\"container\">

            <div class=\"row\">
            \t<br>
                <div class=\"col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Lindas Customizações<br>Ao seu Gosto</h2>
                    <p class=\"lead\">Transforme aquela peça que não te agrada mais em uma peça com estilo diferente, para que você possa sentir-se com a estima elevada ao usá-la novamente</p>
                </div>
                <div class=\"col-lg-5 col-sm-pull-6  col-sm-6\">
                    <img class=\"img-responsive\" src=";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/ant-dep.jpg"), "html", null, true);
        echo " alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->

    <div class=\"content-section-a\">

        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-lg-5 col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Equipamento profissional e<br>Pessoas competentes</h2>
                    <p class=\"lead\">Nada como sentir confiança de que está entregando suas peças nas mãos de quem sabe e pode cuidar muito bem delas, e com carinho e dedicação deixá-las do jeito que você deseja</p>
                </div>
                <div class=\"col-lg-5 col-lg-offset-2 col-sm-6\">
                    <img class=\"img-responsive\" src=";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/atelie.jpg"), "html", null, true);
        echo " alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->
    
    <div class=\"content-section-c\">

        <div class=\"container\">

            <div class=\"row\">
                <br>
                <div class=\"col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Programa Fidelidade para<br>Ainda ganhar muito mais que satisfação</h2>
                    <p class=\"lead\">Oferecemos um programa fidelidade incrível onde você acumula pontos a cada serviço que confia em nossas mãos, podendo trocar por descontos em serviços futuros ou brindes*</p>
                </div>
                <div class=\"col-lg-5 col-sm-pull-6  col-sm-6\">
                    <img class=\"img-responsive\" src=";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("assets/img/fidelidade.jpg"), "html", null, true);
        echo " alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
";
        
        $__internal_46fd0faf5459334cc0f16bc90bf77d0911f6e1085ffed616bd16baeceb512c6e->leave($__internal_46fd0faf5459334cc0f16bc90bf77d0911f6e1085ffed616bd16baeceb512c6e_prof);

        
        $__internal_55edaa06ffb3ce8c1247b314713154fae41b2c1e1933badfb237bff7d3c081c5->leave($__internal_55edaa06ffb3ce8c1247b314713154fae41b2c1e1933badfb237bff7d3c081c5_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 66,  112 => 43,  87 => 21,  72 => 8,  63 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{%  block styles %}
{{ parent() }}
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
{% endblock %}
{% block body %}
<div class=\"content-section-b\">

        <div class=\"container\">

            <div class=\"row\">
            \t<br>
                <div class=\"col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Lindas Customizações<br>Ao seu Gosto</h2>
                    <p class=\"lead\">Transforme aquela peça que não te agrada mais em uma peça com estilo diferente, para que você possa sentir-se com a estima elevada ao usá-la novamente</p>
                </div>
                <div class=\"col-lg-5 col-sm-pull-6  col-sm-6\">
                    <img class=\"img-responsive\" src={{ asset('assets/img/ant-dep.jpg') }} alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-b -->

    <div class=\"content-section-a\">

        <div class=\"container\">

            <div class=\"row\">
                <div class=\"col-lg-5 col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Equipamento profissional e<br>Pessoas competentes</h2>
                    <p class=\"lead\">Nada como sentir confiança de que está entregando suas peças nas mãos de quem sabe e pode cuidar muito bem delas, e com carinho e dedicação deixá-las do jeito que você deseja</p>
                </div>
                <div class=\"col-lg-5 col-lg-offset-2 col-sm-6\">
                    <img class=\"img-responsive\" src={{ asset('assets/img/atelie.jpg') }} alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
    <!-- /.content-section-a -->
    
    <div class=\"content-section-c\">

        <div class=\"container\">

            <div class=\"row\">
                <br>
                <div class=\"col-lg-5 col-lg-offset-1 col-sm-push-6  col-sm-6\">
                    <hr class=\"section-heading-spacer\">
                    <div class=\"clearfix\"></div>
                    <h2 class=\"section-heading\">Programa Fidelidade para<br>Ainda ganhar muito mais que satisfação</h2>
                    <p class=\"lead\">Oferecemos um programa fidelidade incrível onde você acumula pontos a cada serviço que confia em nossas mãos, podendo trocar por descontos em serviços futuros ou brindes*</p>
                </div>
                <div class=\"col-lg-5 col-sm-pull-6  col-sm-6\">
                    <img class=\"img-responsive\" src={{ asset('assets/img/fidelidade.jpg') }} alt=\"\">
                </div>
            </div>

        </div>
        <!-- /.container -->

    </div>
{% endblock %}", "default/index.html.twig", "/home/jadercleber/Workspace/Atelie/app/Resources/views/default/index.html.twig");
    }
}
