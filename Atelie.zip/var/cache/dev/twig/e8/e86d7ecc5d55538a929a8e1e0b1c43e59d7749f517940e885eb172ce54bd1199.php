<?php

/* default/login.html.twig */
class __TwigTemplate_f7671d4db953e357b142b59dfeff1dcab7436bef99d9fe6dd1432b0fc4d65037 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/login.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'body' => array($this, 'block_body'),
            'contato' => array($this, 'block_contato'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ffc9582958656e9dcdee500744b1b2bd0828189387a93408a69599bdd994578 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ffc9582958656e9dcdee500744b1b2bd0828189387a93408a69599bdd994578->enter($__internal_9ffc9582958656e9dcdee500744b1b2bd0828189387a93408a69599bdd994578_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $__internal_a095f576a36086fd5d9fac7283b0430b36e786490251b3cae1b34086e6ba0c75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a095f576a36086fd5d9fac7283b0430b36e786490251b3cae1b34086e6ba0c75->enter($__internal_a095f576a36086fd5d9fac7283b0430b36e786490251b3cae1b34086e6ba0c75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ffc9582958656e9dcdee500744b1b2bd0828189387a93408a69599bdd994578->leave($__internal_9ffc9582958656e9dcdee500744b1b2bd0828189387a93408a69599bdd994578_prof);

        
        $__internal_a095f576a36086fd5d9fac7283b0430b36e786490251b3cae1b34086e6ba0c75->leave($__internal_a095f576a36086fd5d9fac7283b0430b36e786490251b3cae1b34086e6ba0c75_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_25c50ec49a7ba0aea1a32575fab05241a63c7587cb6900bb09c994e71d71c779 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25c50ec49a7ba0aea1a32575fab05241a63c7587cb6900bb09c994e71d71c779->enter($__internal_25c50ec49a7ba0aea1a32575fab05241a63c7587cb6900bb09c994e71d71c779_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        $__internal_b5cae498f6fa68588930d6091d40a33b0f40c6ccf2615bfd4e07aebcc0460132 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b5cae498f6fa68588930d6091d40a33b0f40c6ccf2615bfd4e07aebcc0460132->enter($__internal_b5cae498f6fa68588930d6091d40a33b0f40c6ccf2615bfd4e07aebcc0460132_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        $this->displayParentBlock("styles", $context, $blocks);
        echo "
<link
\thref=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\"
\trel=\"stylesheet\">
";
        
        $__internal_b5cae498f6fa68588930d6091d40a33b0f40c6ccf2615bfd4e07aebcc0460132->leave($__internal_b5cae498f6fa68588930d6091d40a33b0f40c6ccf2615bfd4e07aebcc0460132_prof);

        
        $__internal_25c50ec49a7ba0aea1a32575fab05241a63c7587cb6900bb09c994e71d71c779->leave($__internal_25c50ec49a7ba0aea1a32575fab05241a63c7587cb6900bb09c994e71d71c779_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_987079996e8b334934d4cd3d7a989c2a4918b768b48e068a282dde860c97a978 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_987079996e8b334934d4cd3d7a989c2a4918b768b48e068a282dde860c97a978->enter($__internal_987079996e8b334934d4cd3d7a989c2a4918b768b48e068a282dde860c97a978_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_480aa182e5037c90f92442fa30f9015d80350406986621c1288761992f11bd5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_480aa182e5037c90f92442fa30f9015d80350406986621c1288761992f11bd5d->enter($__internal_480aa182e5037c90f92442fa30f9015d80350406986621c1288761992f11bd5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"intro-header\">
\t<div class=\"container\">

\t\t<div class=\"row\">
\t\t\t<div class=\"col-lg-12\">
\t\t\t\t<div class=\"intro-message\">
\t\t\t\t\t<h1>Bem-vindo</h1>
\t\t\t\t\t<br>
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-offset-4 col-md-4\">
\t\t\t\t\t\t\t\t";
        // line 21
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
\t            \t\t";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "tLogin", array()), 'widget');
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 23
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "tSenha", array()), 'widget');
        echo "
\t\t\t\t\t\t\t\t\t<div class=\"wrapper\">
\t\t\t\t\t\t\t\t\t\t<span class=\"group-btn\">
\t\t\t\t\t\t\t\t\t\t\t";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "save", array()), 'widget');
        echo "
\t\t\t\t\t\t\t\t\t\t\t<!-- <i class=\"fa fa-sign-in\"></i> -->
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t";
        // line 30
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"intro-divider\">
\t\t\t\t\t<!-- <ul class=\"list-inline intro-social-buttons\">
                            <li>
                                <a href=\"https://twitter.com/SBootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-twitter fa-fw\"></i> <span class=\"network-name\">Twitter</span></a>
                            </li>
                            <li>
                                <a href=\"https://github.com/IronSummitMedia/startbootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-github fa-fw\"></i> <span class=\"network-name\">Github</span></a>
                            </li>
                            <li>
                                <a href=\"#\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-linkedin fa-fw\"></i> <span class=\"network-name\">Linkedin</span></a>
                            </li>
                        </ul> -->
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t</div>
\t<!-- /.container -->
</div>

";
        
        $__internal_480aa182e5037c90f92442fa30f9015d80350406986621c1288761992f11bd5d->leave($__internal_480aa182e5037c90f92442fa30f9015d80350406986621c1288761992f11bd5d_prof);

        
        $__internal_987079996e8b334934d4cd3d7a989c2a4918b768b48e068a282dde860c97a978->leave($__internal_987079996e8b334934d4cd3d7a989c2a4918b768b48e068a282dde860c97a978_prof);

    }

    // line 57
    public function block_contato($context, array $blocks = array())
    {
        $__internal_3485e1a278d41bbe943f14109bc4eef1398002a6e9f1f2d49363fc52a441dc48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3485e1a278d41bbe943f14109bc4eef1398002a6e9f1f2d49363fc52a441dc48->enter($__internal_3485e1a278d41bbe943f14109bc4eef1398002a6e9f1f2d49363fc52a441dc48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        $__internal_332718e267256fbf5eb75fc3d56c9e535f6a5851105d742ee277b4a0ddb70e6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_332718e267256fbf5eb75fc3d56c9e535f6a5851105d742ee277b4a0ddb70e6a->enter($__internal_332718e267256fbf5eb75fc3d56c9e535f6a5851105d742ee277b4a0ddb70e6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        
        $__internal_332718e267256fbf5eb75fc3d56c9e535f6a5851105d742ee277b4a0ddb70e6a->leave($__internal_332718e267256fbf5eb75fc3d56c9e535f6a5851105d742ee277b4a0ddb70e6a_prof);

        
        $__internal_3485e1a278d41bbe943f14109bc4eef1398002a6e9f1f2d49363fc52a441dc48->leave($__internal_3485e1a278d41bbe943f14109bc4eef1398002a6e9f1f2d49363fc52a441dc48_prof);

    }

    public function getTemplateName()
    {
        return "default/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 57,  109 => 30,  102 => 26,  96 => 23,  92 => 22,  88 => 21,  75 => 10,  66 => 9,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{%  block styles %}
{{ parent() }}
<link
\thref=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\"
\trel=\"stylesheet\">
{% endblock %}
{% block body %}
<div class=\"intro-header\">
\t<div class=\"container\">

\t\t<div class=\"row\">
\t\t\t<div class=\"col-lg-12\">
\t\t\t\t<div class=\"intro-message\">
\t\t\t\t\t<h1>Bem-vindo</h1>
\t\t\t\t\t<br>
\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t<div class=\"col-md-offset-4 col-md-4\">
\t\t\t\t\t\t\t\t{{ form_start(form) }}
\t            \t\t{{ form_widget(form.tLogin) }}
\t\t\t\t\t\t\t\t\t{{ form_widget(form.tSenha) }}
\t\t\t\t\t\t\t\t\t<div class=\"wrapper\">
\t\t\t\t\t\t\t\t\t\t<span class=\"group-btn\">
\t\t\t\t\t\t\t\t\t\t\t{{ form_widget(form.save) }}
\t\t\t\t\t\t\t\t\t\t\t<!-- <i class=\"fa fa-sign-in\"></i> -->
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t{{ form_end(form) }}

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<hr class=\"intro-divider\">
\t\t\t\t\t<!-- <ul class=\"list-inline intro-social-buttons\">
                            <li>
                                <a href=\"https://twitter.com/SBootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-twitter fa-fw\"></i> <span class=\"network-name\">Twitter</span></a>
                            </li>
                            <li>
                                <a href=\"https://github.com/IronSummitMedia/startbootstrap\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-github fa-fw\"></i> <span class=\"network-name\">Github</span></a>
                            </li>
                            <li>
                                <a href=\"#\" class=\"btn btn-default btn-lg\"><i class=\"fa fa-linkedin fa-fw\"></i> <span class=\"network-name\">Linkedin</span></a>
                            </li>
                        </ul> -->
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t</div>
\t<!-- /.container -->
</div>

{% endblock %}

{% block contato %}
{% endblock %}
", "default/login.html.twig", "/home/jadercleber/Workspace/Atelie/app/Resources/views/default/login.html.twig");
    }
}
