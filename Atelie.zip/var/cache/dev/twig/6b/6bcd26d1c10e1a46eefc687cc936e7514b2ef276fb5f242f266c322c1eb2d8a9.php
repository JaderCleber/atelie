<?php

/* default/app-main.html.twig */
class __TwigTemplate_be4da38c4bb5915f0b5e50438d34e0e98367f1c422f8552738376d729aee5ad1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/app-main.html.twig", 1);
        $this->blocks = array(
            'styles' => array($this, 'block_styles'),
            'menu' => array($this, 'block_menu'),
            'body' => array($this, 'block_body'),
            'contato' => array($this, 'block_contato'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_17b7a959897c01ebc479fa7db88c6af278890ec69c4f4e928465c8171807ae48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_17b7a959897c01ebc479fa7db88c6af278890ec69c4f4e928465c8171807ae48->enter($__internal_17b7a959897c01ebc479fa7db88c6af278890ec69c4f4e928465c8171807ae48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/app-main.html.twig"));

        $__internal_22a17ffcfac8e5e9097b8cd875758e61edf722af4e8461e9e4d5baabbcd01fff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22a17ffcfac8e5e9097b8cd875758e61edf722af4e8461e9e4d5baabbcd01fff->enter($__internal_22a17ffcfac8e5e9097b8cd875758e61edf722af4e8461e9e4d5baabbcd01fff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/app-main.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_17b7a959897c01ebc479fa7db88c6af278890ec69c4f4e928465c8171807ae48->leave($__internal_17b7a959897c01ebc479fa7db88c6af278890ec69c4f4e928465c8171807ae48_prof);

        
        $__internal_22a17ffcfac8e5e9097b8cd875758e61edf722af4e8461e9e4d5baabbcd01fff->leave($__internal_22a17ffcfac8e5e9097b8cd875758e61edf722af4e8461e9e4d5baabbcd01fff_prof);

    }

    // line 3
    public function block_styles($context, array $blocks = array())
    {
        $__internal_3c9d598033682035ba895b24bd9177bf02f5ba1f0e7a3c7a7b34e37b854fb573 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c9d598033682035ba895b24bd9177bf02f5ba1f0e7a3c7a7b34e37b854fb573->enter($__internal_3c9d598033682035ba895b24bd9177bf02f5ba1f0e7a3c7a7b34e37b854fb573_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        $__internal_d4b2063399341afac37f16b9044042263185be62031d6c38717c620dfc91a1d7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4b2063399341afac37f16b9044042263185be62031d6c38717c620dfc91a1d7->enter($__internal_d4b2063399341afac37f16b9044042263185be62031d6c38717c620dfc91a1d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "styles"));

        // line 4
        $this->displayParentBlock("styles", $context, $blocks);
        echo "
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
";
        
        $__internal_d4b2063399341afac37f16b9044042263185be62031d6c38717c620dfc91a1d7->leave($__internal_d4b2063399341afac37f16b9044042263185be62031d6c38717c620dfc91a1d7_prof);

        
        $__internal_3c9d598033682035ba895b24bd9177bf02f5ba1f0e7a3c7a7b34e37b854fb573->leave($__internal_3c9d598033682035ba895b24bd9177bf02f5ba1f0e7a3c7a7b34e37b854fb573_prof);

    }

    // line 8
    public function block_menu($context, array $blocks = array())
    {
        $__internal_329a740f7a1de485c14b56ca708b2a64afede03468e1f80bf89a2bab818a2008 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_329a740f7a1de485c14b56ca708b2a64afede03468e1f80bf89a2bab818a2008->enter($__internal_329a740f7a1de485c14b56ca708b2a64afede03468e1f80bf89a2bab818a2008_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_3a4251e65a0a038006b94e78893186cedd889e7535a068466e036b45002a63b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a4251e65a0a038006b94e78893186cedd889e7535a068466e036b45002a63b1->enter($__internal_3a4251e65a0a038006b94e78893186cedd889e7535a068466e036b45002a63b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 9
        echo "  <li>
      <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("servicos");
        echo "\">Etc</a>
  </li>
  <li>
      <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("sucessos");
        echo "\">Conta</a>
  </li>
  <li>
      <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\">Sair</a>
  </li>
";
        
        $__internal_3a4251e65a0a038006b94e78893186cedd889e7535a068466e036b45002a63b1->leave($__internal_3a4251e65a0a038006b94e78893186cedd889e7535a068466e036b45002a63b1_prof);

        
        $__internal_329a740f7a1de485c14b56ca708b2a64afede03468e1f80bf89a2bab818a2008->leave($__internal_329a740f7a1de485c14b56ca708b2a64afede03468e1f80bf89a2bab818a2008_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_fb4e02642523ae49a13d0eb192517569fa823a311c7ace3c6fce0893a93316f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb4e02642523ae49a13d0eb192517569fa823a311c7ace3c6fce0893a93316f6->enter($__internal_fb4e02642523ae49a13d0eb192517569fa823a311c7ace3c6fce0893a93316f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_cfa3174038146610c09090a92349c4d541df95ce2d7952c085256ad4e7170de8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cfa3174038146610c09090a92349c4d541df95ce2d7952c085256ad4e7170de8->enter($__internal_cfa3174038146610c09090a92349c4d541df95ce2d7952c085256ad4e7170de8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "<div class=\"content-section-b\">

    <div class=\"container\">

      <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1 class=\"page-header\"><font style=\"background-color:#000; color:#fff;\">Bem-Vindo ";
        // line 27
        echo twig_escape_filter($this->env, $this->getAttribute(($context["session"] ?? $this->getContext($context, "session")), "idUsuario", array()), "html", null, true);
        echo "</font>
            </h1>
        </div>

        <!-- Botao para o controle de clientes -->
        <a href=\"";
        // line 32
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de produtos -->
        <a href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_produtos");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Produtos</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de funcionarios -->
        <a href=\"";
        // line 54
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_funcionarios");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Funcionários</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de empresas -->
        <a href=\"";
        // line 65
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_empresas");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Empresas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de caixa -->
        <a href=\"";
        // line 76
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_caixa");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Caixa</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para controle de Pedidos/Encomendas -->
        <a href=\"";
        // line 87
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_pedidos");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Pedidos/Encomendas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao aguardando atribuição -->
        <!-- <a href=\"";
        // line 98
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a> -->

        <!-- Botao aguardando atribuição -->
        <!-- <a href=\"";
        // line 109
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_clientes");
        echo "\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a> -->
      </div>
    </div>
    <!-- /.container -->
</div>
    <!-- /.content-section-b -->
";
        
        $__internal_cfa3174038146610c09090a92349c4d541df95ce2d7952c085256ad4e7170de8->leave($__internal_cfa3174038146610c09090a92349c4d541df95ce2d7952c085256ad4e7170de8_prof);

        
        $__internal_fb4e02642523ae49a13d0eb192517569fa823a311c7ace3c6fce0893a93316f6->leave($__internal_fb4e02642523ae49a13d0eb192517569fa823a311c7ace3c6fce0893a93316f6_prof);

    }

    // line 125
    public function block_contato($context, array $blocks = array())
    {
        $__internal_251604734a8afd48b87c6b3501739e3591fb92a0aca098f35adb81d5d9566331 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_251604734a8afd48b87c6b3501739e3591fb92a0aca098f35adb81d5d9566331->enter($__internal_251604734a8afd48b87c6b3501739e3591fb92a0aca098f35adb81d5d9566331_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        $__internal_30306db7979fab73b5ed3ef522cc7d1adb893e34e981eb5a25bb9010af97bec5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_30306db7979fab73b5ed3ef522cc7d1adb893e34e981eb5a25bb9010af97bec5->enter($__internal_30306db7979fab73b5ed3ef522cc7d1adb893e34e981eb5a25bb9010af97bec5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "contato"));

        
        $__internal_30306db7979fab73b5ed3ef522cc7d1adb893e34e981eb5a25bb9010af97bec5->leave($__internal_30306db7979fab73b5ed3ef522cc7d1adb893e34e981eb5a25bb9010af97bec5_prof);

        
        $__internal_251604734a8afd48b87c6b3501739e3591fb92a0aca098f35adb81d5d9566331->leave($__internal_251604734a8afd48b87c6b3501739e3591fb92a0aca098f35adb81d5d9566331_prof);

    }

    public function getTemplateName()
    {
        return "default/app-main.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  250 => 125,  225 => 109,  211 => 98,  197 => 87,  183 => 76,  169 => 65,  155 => 54,  141 => 43,  127 => 32,  119 => 27,  111 => 21,  102 => 20,  89 => 16,  83 => 13,  77 => 10,  74 => 9,  65 => 8,  52 => 4,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{%  block styles %}
{{ parent() }}
<link href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css\" rel=\"stylesheet\">
{% endblock %}

{% block menu %}
  <li>
      <a href=\"{{ path('servicos') }}\">Etc</a>
  </li>
  <li>
      <a href=\"{{ path('sucessos') }}\">Conta</a>
  </li>
  <li>
      <a href=\"{{ path('login') }}\">Sair</a>
  </li>
{% endblock %}

{% block body %}
<div class=\"content-section-b\">

    <div class=\"container\">

      <div class=\"row\">
        <div class=\"col-lg-12\">
            <h1 class=\"page-header\"><font style=\"background-color:#000; color:#fff;\">Bem-Vindo {{ session.idUsuario }}</font>
            </h1>
        </div>

        <!-- Botao para o controle de clientes -->
        <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de produtos -->
        <a href=\"{{ path('app_produtos')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Produtos</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de funcionarios -->
        <a href=\"{{ path('app_funcionarios')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Funcionários</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de empresas -->
        <a href=\"{{ path('app_empresas')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Empresas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para o controle de caixa -->
        <a href=\"{{ path('app_caixa')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Caixa</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao para controle de Pedidos/Encomendas -->
        <a href=\"{{ path('app_pedidos')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Pedidos/Encomendas</h4>
                    </div>
                </div>
            </div>
        </a>

        <!-- Botao aguardando atribuição -->
        <!-- <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a> -->

        <!-- Botao aguardando atribuição -->
        <!-- <a href=\"{{ path('app_clientes')}}\" style=\"text-align: center;\">
            <div class=\"col-md-3\">
                <div class=\"panel panel-default\">
                    <div class=\"panel-heading\">
                        <h4><img src=\"img/i.png\"></i> Clientes</h4>
                    </div>
                </div>
            </div>
        </a> -->
      </div>
    </div>
    <!-- /.container -->
</div>
    <!-- /.content-section-b -->
{% endblock %}

{% block contato %}
{% endblock %}
", "default/app-main.html.twig", "/home/jadercleber/Workspace/Atelie/app/Resources/views/default/app-main.html.twig");
    }
}
